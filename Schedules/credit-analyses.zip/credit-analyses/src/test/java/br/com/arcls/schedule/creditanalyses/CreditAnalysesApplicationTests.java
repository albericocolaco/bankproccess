package br.com.arcls.schedule.creditanalyses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditAnalysesApplicationTests {

	@Test
	void contextLoads() {
	}

}
