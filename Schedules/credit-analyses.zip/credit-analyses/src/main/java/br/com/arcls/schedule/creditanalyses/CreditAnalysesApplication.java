package br.com.arcls.schedule.creditanalyses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditAnalysesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditAnalysesApplication.class, args);
	}

}
