package br.com.arcls.schedule.fraudanalyses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudAnalysesApplicationTests {

	@Test
	void contextLoads() {
	}

}
