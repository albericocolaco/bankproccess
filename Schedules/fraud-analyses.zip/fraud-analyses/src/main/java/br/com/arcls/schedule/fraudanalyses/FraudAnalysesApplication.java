package br.com.arcls.schedule.fraudanalyses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudAnalysesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudAnalysesApplication.class, args);
	}

}
