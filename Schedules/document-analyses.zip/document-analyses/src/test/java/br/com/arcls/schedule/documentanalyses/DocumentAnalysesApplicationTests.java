package br.com.arcls.schedule.documentanalyses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentAnalysesApplicationTests {

	@Test
	void contextLoads() {
	}

}
